/* file: sdb.run.pl -- prints the sdb tables */

run:-printDbase(sdb).
