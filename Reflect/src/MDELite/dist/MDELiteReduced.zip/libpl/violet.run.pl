/* file violet.run.pl */

run:-printDbase(violet).

